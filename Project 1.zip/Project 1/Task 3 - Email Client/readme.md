# Task 3

This assignment is slightly extended from the prompt by providing:

+ Plaintext formatting support
+ Sample attachment support, you can provide one text file as an attachment given by the second argument

It's a demonstration of some more capabilities of the `email.mime.application` class in the standard library

Note that gmail accounts will have the SMTP server completed automatically.
